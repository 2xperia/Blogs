var express = require('express');

var router = express.Router();

var datajson = require('../public/javascripts/data.json');

var username =datajson.users[0].username;

var password = datajson.users[0].password;

var chapterList = datajson.chapterList;

router.get('/', function(req,res,next) {

    res.render('login');

});
router.post('/list', function(req, res, next) {

    if(username == req.body.username && password == req.body.password){

        res.render('list',{ chapterList:chapterList });

    }
    else{

        res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});

        res.write('您输入的用户名或者密码错误，请返回重新输入');
        
    }
    res.end(); 

})

module.exports = router;